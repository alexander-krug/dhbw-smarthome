const n=(n,o)=>n&&n.config.components.includes(o);export{n as i};
