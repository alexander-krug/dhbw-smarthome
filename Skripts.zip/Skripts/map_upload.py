import requests
import os
from dotenv import load_dotenv
from append_map import append_map
from update_map import update_map
from create_description import create_description

load_dotenv()

url = 'https://maphub.net/api/1/map/get'

api_key = os.getenv('MAP_HUB_KEY')

args = {
    'map_id': os.getenv('MAP_ID'),
}

description=create_description()

headers = {'Authorization': 'Token ' + api_key}

#Get Map from MapHub
r = requests.post(url, json=args, headers=headers)

old_json = r.json()["geojson"]
exists=False
print(old_json)

#Exchange Description from given Point and upload
for feature in old_json["features"]:
    if feature["properties"]["title"] == "DHBW-Energie":
        feature["properties"]["description"]=description
        exists=True
        update_map(old_json)
if exists == False:
    #if point doesnt exist yet, it will be created
    append_map(description)

