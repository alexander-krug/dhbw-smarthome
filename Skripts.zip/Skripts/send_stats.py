import requests
import os
from dotenv import load_dotenv


load_dotenv()



url = 'http://'+os.getenv('HA_ADRESS')+'/api/states'
url_energy = 'http://'+os.getenv('HA_ADRESS')+'/api/states/'+os.getenv('ENERGY_SENSOR')
url_power = 'http://'+os.getenv('HA_ADRESS')+'/api/states/'+os.getenv('POWER_SENSOR')
url_upload = os.getenv('API_URL')


stats={"Aktuelle Woche": None,
        "Aktueller Monat": None,
        "Aktuelles Jahr": None,
        "Gestern": None,
        "Letzte Woche": None,
        "Letzter Monat": None,
        "Letztes Jahr": None}

api_key = os.getenv('HA_TOKEN')
api_key1pm = os.getenv('HA_TOKEN1PM')

headers = {'Authorization': 'Bearer ' + api_key,
        "content-type": "application/json"}

#Get Data from Home Assistant
r = requests.get(url, headers=headers)
if r.status_code==401:
    headers = {'Authorization': 'Bearer ' + api_key1pm,
        "content-type": "application/json"}
r = requests.get(url, headers=headers)

#Go over Data From Home Assistant and find fitting values
try:
    entities=r.json()
    for stat in stats:
        print(stat)
        for entity in entities:
            try:
                if entity["attributes"]["friendly_name"]==stat:
                    if entity["state"]=="unknown":
                        stats[stat]="not available"
                    else:
                        stats[stat]=str(round(float(entity["state"]), 2))+entity["attributes"]["unit_of_measurement"]
            except:
                pass
except Exception as error:
    print("Misstake" + str(error))

#Get more Data from Home Assistant and put into JSON
try:
    r = requests.get(url_energy, headers=headers)
    stats["Heute"]=str(round(float(r.json()["state"]), 2))+r.json()["attributes"]["unit_of_measurement"]

    r = requests.get(url_power, headers=headers)
    stats["Aktuell"]=str(round(float(r.json()["state"]), 2))+r.json()["attributes"]["unit_of_measurement"]

except :
    stats["Heute"]=None
    stats["Aktuell"]=None

headers_WP = {'Authorization': os.getenv('WP_TOKEN')}

print(stats)

#Upload Data to API in Google Cloud
r = requests.post(url_upload, json=stats, headers=headers_WP)
print(r)



print(stats)
        



    
