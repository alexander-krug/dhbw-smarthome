import requests
import os
from dotenv import load_dotenv

load_dotenv()

#Creation of the Description for the Map
def create_description():
    #Adresses to get Data from Home Assistant
    url_energy = 'http://'+os.getenv('HA_ADRESS')+'/api/states/'+os.getenv('ENERGY_SENSOR')
    url_power = 'http://'+os.getenv('HA_ADRESS')+'/api/states/'+os.getenv('POWER_SENSOR')

    #Home Assistant Token
    api_key = os.getenv('HA_TOKEN')
    api_key1pm = os.getenv('HA_TOKEN1PM')

    headers = {'Authorization': 'Bearer ' + api_key,
            "content-type": "application/json"}
    
    #Get values from Home Assistant API
    try:
        r = requests.get(url_energy, headers=headers)
        
        #Try Key of different HA instance
        if r.status_code==401:
            headers = {'Authorization': 'Bearer ' + api_key1pm,
            "content-type": "application/json"}

        r = requests.get(url_energy, headers=headers)
        energy=str(round(float(r.json()["state"]), 2))+r.json()["attributes"]["unit_of_measurement"]
        print(energy)

        r = requests.get(url_power, headers=headers)
        power=str(round(float(r.json()["state"]), 2))+r.json()["attributes"]["unit_of_measurement"]

        #Create Description
        description = "Aktuell: "+power+"\nHeute: "+energy
        
        return description
    
    except Exception as error:
        description = "Aktuell: 0\nHeute: 0"
        return description
        #return str(error)