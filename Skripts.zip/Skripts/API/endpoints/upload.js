
const fs = require('fs').promises;

const upload = async (req, res) => {

    //check if token is correct
    if (req.header('Authorization') == process.env.WP_TOKEN) {
        var body = JSON.stringify(req.body)
        console.log(body)

        //write json to file
        await fs.writeFile('json.txt', body);
        return res.sendStatus(200)
    }
    else{
        return res.sendStatus(405)
    }


}




module.exports = { upload }