const express = require("express");
const https = require("https");
const fs = require("fs");
const dotenv = require('dotenv');

//load .env
dotenv.config();

//import methods
const { upload } = require('./endpoints/upload'); 
const { stats } = require('./endpoints/stats'); 




//initiate express
const app = express();
app.use(express.json());


//Set Endpoints to different methods
app.get('/api/stats', stats); 
app.post('/api/upload', upload); 

//start Server
https
  .createServer(
		// Provide the private and public key to the server by reading each
		// file's content with the readFileSync() method.
    {
      key: fs.readFileSync("/etc/letsencrypt/live/schwabencontrol.com-0001/privkey.pem"),
      cert: fs.readFileSync("/etc/letsencrypt/live/schwabencontrol.com-0001/cert.pem"),
    },
    app
  )
  .listen(4000, () => {
    console.log("server is runing at port 4000");
  });
