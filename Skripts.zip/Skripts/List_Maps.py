import requests
import os
from dotenv import load_dotenv

load_dotenv()

url = 'https://maphub.net/api/1/map/list'

api_key = os.getenv('MAP_HUB_KEY')

headers = {'Authorization': 'Token ' + api_key}
r = requests.post(url, headers=headers)

print(r.json())