import requests
import os
from dotenv import load_dotenv
load_dotenv()

url = 'https://maphub.net/api/1/map/update'

api_key = os.getenv('MAP_HUB_KEY')

def update_map(old_json):

    args = {
        'map_id': os.getenv('MAP_ID'),
        'geojson': old_json,
    }

    headers = {'Authorization': 'Token ' + api_key}
    #upload map
    r = requests.post(url, json=args, headers=headers)

    print(r.json())