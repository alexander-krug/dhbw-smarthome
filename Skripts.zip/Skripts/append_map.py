import json
import os
import requests
from dotenv import load_dotenv

load_dotenv()

def append_map(description):
    url = 'https://maphub.net/api/1/map/append'

    api_key = os.getenv('MAP_HUB_KEY')

    args = {
        'map_id': os.getenv('MAP_ID'),
        'file_type': 'geojson',
    }

    headers = {
        'Authorization': 'Token ' + api_key,
        'MapHub-API-Arg': json.dumps(args),
    }

    #point that will be added to Map
    geojson = {
        "type": "FeatureCollection",
        "features": [
            {
                "type": "Feature",
                "geometry": {"type": "Point", "coordinates": [float(os.getenv('X_COORDINATE')), float(os.getenv('Y_COORDINATE'))]},
                "properties": {
                    "title": 'DHBW-Energie',
                    "description": description
                },
            }
        ],
    }


    r = requests.post(url, headers=headers, data=json.dumps(geojson))
    print(r.json())