import requests
import os
from dotenv import load_dotenv

load_dotenv()

url = 'https://www.data199.com/api/pv1/device/lastmeasurement'

#define IDs
data={"deviceids": os.getenv('DEVICE_ID'), "phoneid": os.getenv('PHONE_ID')}

headers = {'Content-Type': 'application/x-www-form-urlencoded'}

#Get Data
r = requests.post(url, data = data, headers=headers)

#Find Data in JSON
print(r.json())
temperature=r.json()["devices"][0]["measurement"]["t1"]
humidity=r.json()["devices"][0]["measurement"]["h"]

print(temperature)
print(humidity)

#Upload Temperature to Home Assistant
url_temperature = "http://localhost:8123/api/states/sensor.temperatur"
headers = {"Authorization": "Bearer "+os.getenv('HA_TOKEN'), "content-type": "application/json"}
data = {"state": temperature, "attributes": {"unit_of_measurement": "°C"}}
r = requests.post(url_temperature, json = data, headers=headers)
print(r)

#Upload Humidity to Home Assistant
url_humidity = "http://localhost:8123/api/states/sensor.luftfeuchtigkeit"
headers = {"Authorization": "Bearer "+os.getenv('HA_TOKEN'), "content-type": "application/json"}
data = {"state": humidity, "attributes": {"unit_of_measurement": "%"}}
r = requests.post(url_humidity, json = data, headers=headers)

print(r)

#Try Token of different Home Assistant (1pm)
if r.status_code==401:
    url_temperature = "http://localhost:8123/api/states/sensor.temperatur"
    headers = {"Authorization": "Bearer "+os.getenv('HA_TOKEN1PM'), "content-type": "application/json"}
    data = {"state": temperature, "attributes": {"unit_of_measurement": "°C"}}

    r = requests.post(url_temperature, json = data, headers=headers)
    print(r)
    url_humidity = "http://localhost:8123/api/states/sensor.luftfeuchtigkeit"
    headers = {"Authorization": "Bearer "+os.getenv('HA_TOKEN1PM'), "content-type": "application/json"}
    data = {"state": humidity, "attributes": {"unit_of_measurement": "%"}}


    r = requests.post(url_humidity, json = data, headers=headers)
    print(r)

