const express = require("express");
const https = require("https");
const fs = require("fs");
const dotenv = require('dotenv');
//const cors = require('cors')
//env Variablen setzen
dotenv.config();

//Methoden importieren 
const { upload } = require('./endpoints/upload'); 
const { stats } = require('./endpoints/stats'); 


//Cors Setup
const corsOptions = {
  origin: 'http://neneoo.com',
  optionsSuccessStatus: 200, // manche legacy browsers (IE11, various SmartTVs) choken an 204
  credentials: true
}

//express und cors initiieren
const app = express();
app.use(express.json());
//app.use(cors(corsOptions));

//Endpoints auf die verschiedenen Methoden setzen
//uid und role werden immer im ApiGW aus dem Token aufgelöst --> nicht verfälschbar
app.options('/*') // CORS pre-flight
app.get('/api/stats', stats); 
app.post('/api/upload', upload); 

//Server starten
https
  .createServer(
		// Provide the private and public key to the server by reading each
		// file's content with the readFileSync() method.
    {
      key: fs.readFileSync("/etc/letsencrypt/live/schwabencontrol.com-0001/privkey.pem"),
      cert: fs.readFileSync("/etc/letsencrypt/live/schwabencontrol.com-0001/fullchain.pem"),
    },
    app
  )
  .listen(4000, () => {
    console.log("server is runing at port 4000");
  });
