const fs = require('fs').promises;

const stats = async (req, res) => {



    var file = await fs.readFile('json.txt', 'utf8');
    if (file != "") {
        return res.status(200).json(JSON.parse(file)).end()
    } else {
        return res.status(200).json({}).end()
    }




}




module.exports = { stats }
