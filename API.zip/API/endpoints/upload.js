const fs = require('fs').promises;

const upload = async (req, res) => {
console.log(process.env.WP_TOKEN)
    if (req.header('Authorization') == process.env.WP_TOKEN) {
        var body = JSON.stringify(req.body)
        console.log(body)

        await fs.writeFile('json.txt', body);
        return res.sendStatus(200)
    }
    else{
        return res.sendStatus(405)
    }


}




module.exports = { upload }
